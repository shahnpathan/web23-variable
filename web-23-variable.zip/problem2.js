var Name=" Shahin Munwar Pathan";
Name="Munwar Ramzan Pathan";
Name="Halima Munwar Pathan";
console.log(Name);