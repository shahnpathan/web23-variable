let a=10;
let b=2;
console.log((a+b)**b);
console.log("hello world"+"\n"+"Masai");