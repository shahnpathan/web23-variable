let x=3;
let y=1;
console.log((((x+y)**(x-y)*(y**2)+(x**3))));