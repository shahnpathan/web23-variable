let a=3;
let b=2;
console.log("sum is ",a+b);
console.log("sub is",a-b);
console.log(multi is)