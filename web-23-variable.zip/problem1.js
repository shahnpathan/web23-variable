let x="Masai school";
console.log(x);
let y="A Transformation In Education"
console.log(y)