let N=12;
if (N%4){console.log("Yes");}
else{console.log("No");}