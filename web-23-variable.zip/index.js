
var x=12;
console.log(x);
let Y=122;
Y=298;
console.log(Y);
const z=123;
console.log(z);