let name= "shaheen Pathan";
console.log(name);
let school="Urdu High School";
console.log(school);
let a="grade";
console.log(a);
let grade="A+";
console.log(grade);
let s="section";
console.log(s);
let section="D";
console.log(section); 
let r="roll-no.";
console.log(r);
let roll_no=11;
console.log(roll_no);
let sub1="English";
console.log(sub1);
let e=95;
console.log(e);
let M="Mathematics";
console.log(M);
let m=91;
console.log(m);
let S="Science";
console.log(S);
let f=93;
console.log(f);




