let a=4000;
let b=3999;
if (a>=b) {console.log("Got discount");
  
}else{
  consol.log("Not Elligible");
}