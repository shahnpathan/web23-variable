var Name="Shahin Pathan";
console.log(Name);
var age=21;
console.log( typeof(a));

